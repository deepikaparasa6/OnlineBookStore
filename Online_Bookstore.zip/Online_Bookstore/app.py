from flask import Flask, render_template, jsonify
import json
import os

app = Flask(__name__)

# Load book data
with open(os.path.join("data", "books.json"), "r", encoding="utf-8") as f:
    books = json.load(f)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/books")
def show_books():
    return render_template("books.html", books=books)

@app.route("/api/books")
def api_books():
    return jsonify(books)

if __name__ == "__main__":
    app.run(debug=True)
